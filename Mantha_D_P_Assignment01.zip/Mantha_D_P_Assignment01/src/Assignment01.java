import java.util.*;
public class Assignment01 
{
   
	public static void main(String args[])
	{
		
		/*
		 * I have defined all the methods of problems in same class
		 * to verify a problem given, please kindly un-comment the method which is commented in main method
		 */
		
		
		//problem1();
		//problem2();
		//problem3();
		 //problem4();
		//problem5();
		//problem6();
		//problem7();
		//problem8(); 
		//problem9() ;
		problem10() ;
		
		
	}
	
	
	
	
	private static void problem1() {

		Scanner scan = new Scanner(System.in);
		
		// problem 1
		
		List<Integer> linkedList1 = new LinkedList<>();
		
		System.out.println("Enter lenght of list: ");
		int l1Length = scan.nextInt();
		
		while(l1Length > 0) {
			System.out.println("Enter the numbers: ");
			int k = scan.nextInt();
			linkedList1.add(k);
			l1Length --;
		}
		List<Integer> linkedList2 = new LinkedList<>();
		
		Iterator<Integer> itr = linkedList1.iterator();
		
		while(itr.hasNext()) {
			int num = itr.next();
			int sum = 0;
			for( int i=1; i< num; i++) {
				if(num%i == 0) {
					sum = sum + i;
				}
			}
			if( sum == num) {
				linkedList2.add(num);
			}
		}
	    System.out.println("The list entered by user: "+linkedList1);
	    System.out.println("  ");
		System.out.println("The list of perfect numbers is: "+linkedList2);
	}
	
	
	
	public static void problem2() 
	{
		Scanner key = new Scanner(System.in);
		
		LinkedList <Integer> linkedList1 = new LinkedList<Integer>();
		System.out.println("Enter the size of list: ");
		int size= key.nextInt();
		
		//taking input elements for list
		while(size > 0) {
			System.out.println("Enter the numbers: ");
			int l = key.nextInt();
			linkedList1.add(l);
			size --;
		}
		
		//taking the value of k
		
		System.out.println("Enter the value of k: ");
		int k = key.nextInt();
		
		LinkedList<Integer> linkedList2 = new LinkedList<>();
		
		Iterator<Integer> itr = linkedList1.iterator();
		
		for(int i=0;i<linkedList1.size()-1;i++) 
		{
			 if (linkedList1.get(i) + linkedList1.get(i+1)== k)
			 {
				 linkedList2.add(linkedList1.get(i));
				 linkedList2.add(linkedList1.get(i+1));
			 }
			
		}
		 System.out.println("The list entered by user: "+linkedList1);
		    System.out.println("  ");
		System.out.println("The modified list of successive numbers with sum k : "+linkedList2);
	}
	
	public static void problem3()
	{
		List<Integer> arrayList1 = new ArrayList<Integer>();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of array: ");
		int size= scan.nextInt();
		
	//taking input from user for array elements
		while(size > 0) {
			System.out.println("Enter the numbers: ");
			int l = scan.nextInt();
			arrayList1.add(l);
			size --;
		}
		
		List<Integer> arrayList2 = new ArrayList<Integer>();
		for(int i=0; i<arrayList1.size()-1;i++)
		{
			int maxNum=arrayList1.get(i);
			if(arrayList1.get(i+1)>maxNum)
			{
				maxNum =arrayList1.get(i+1);
			}
			arrayList2.add(maxNum);
		}
		
		 System.out.println("The list entered by user: "+arrayList1);
		    System.out.println("  ");
		System.out.println("The maximum number of array is : "+ arrayList2.get(arrayList2.size()-1));
		
	}
	
	public static void problem4()
	{
		List<String> arrayList1 = new ArrayList<String>();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter size of array: ");
		int size= scan.nextInt();
		
		System.out.println("Enter "+ size + " names");
		
		//taking input from users
		while(size>0)
		{
			String s= scan.next();
			arrayList1.add(s);
			size --;
			
		}
		
		System.out.println("The list entered by user: "+arrayList1);
		arrayList1.sort((first, second) -> Integer.compare(first.length(),
                second.length()));
		
		 
		    System.out.println("  ");
		System.out.println("The list after sorting string by length "+ arrayList1);
		
		
	}
	
	
	static boolean balancedExpression(String expr)
    {
        // Using ArrayDeque is faster than using Stack class
        Deque<Character> stack
            = new ArrayDeque<Character>();
 
        // Traversing the Expression
        for (int i = 0; i < expr.length(); i++)
        {
            char x = expr.charAt(i);
 
            if (x == '(' || x == '[' || x == '{')
            {
                // Push the element in the stack
                stack.push(x);
                continue;
            }
 
            // If current character is not opening
            // bracket, then it must be closing. So stack
            // cannot be empty at this point.
            if (stack.isEmpty())
                return false;
            char check;
            switch (x) {
            case ')':
                check = stack.pop();
                if (check == '{' || check == '[')
                    return false;
                break;
 
            case '}':
                check = stack.pop();
                if (check == '(' || check == '[')
                    return false;
                break;
 
            case ']':
                check = stack.pop();
                if (check == '(' || check == '{')
                    return false;
                break;
            }
        }
 
        // Check Empty Stack
        return (stack.isEmpty());
    }
 public static void problem5() 
 {
	  Scanner scan = new Scanner(System.in);
	  System.out.println("Enter the expression: ");
	  String expr1= scan.next();
	  System.out.println("");
	  if (balancedExpression(expr1))
          System.out.println("True ");
      else
          System.out.println("False ");
	  
 }
 
 public static void problem6()
 {
	 Stack<Integer> l = new Stack<>();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length of Stack");
		
		int len = scan.nextInt() ;
		if(len%2 == 0) { 
			System.out.println("Enter "+len+ " numbers");
			for(int i=0; i<len;i++) {
				l.add(scan.nextInt());
			}
			System.out.println("List of Integers by user : " + l);
			
			List<Integer> l1 = new ArrayList<Integer>();
			
			for(int i=len;i>len/2;i--) {
				l1.add(l.get(i-1));
			}
			for(int i=0;i<len/2;i++) {
				l1.add(l.get(i));
			}
			System.out.println("List of Integers after rearranging : " + l1);
			
		}else {
			System.out.println("Enter even number for length of the Stack");
		}
 }

public static void problem7()
{
	Queue<String> q1 =new LinkedList<>();
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter number of binary elements : ");
	int a = scan.nextInt();
	System.out.println("Enter the binary values:");
	for(int k=0;k<a;k++) {
		q1.add(scan.next());
		}
	System.out.println("Entered list : "+q1);
	System.out.println("binary number of entered list : "+binayCalculation(q1));
}
public static int binayCalculation(Queue<String> queue1) 
{	
	String s = "";
	for (String item: queue1) {
		s += item;
    }
	
	return Integer.parseInt(s,2);
}
 

public static void problem8() 
{
	Scanner scan = new Scanner(System.in);
	Deque<Integer> arrayDeque1 = new ArrayDeque<>();
	System.out.println("Enter number of elements:");
	int size = scan.nextInt();
	System.out.println("Enter the elements");
	for (int i = 0; i < size; i++) {
		int k1 = scan.nextInt();
		arrayDeque1.add(k1);
	}

	System.out.println("Entered list of numbers: " + arrayDeque1);
	List<Integer> l = alterList(arrayDeque1);
	System.out.println("the new altered list : " + l);
	
}

public static List<Integer> alterList(Deque<Integer> queue1) {
	List<Integer> l1 = new ArrayList<>();
	while (!queue1.isEmpty()) {
		l1.add(queue1.pollLast());
		if (!queue1.isEmpty())
			l1.add(queue1.pollFirst());

	}
	return l1;
}

public static void problem9() 
{
	Scanner scan = new Scanner(System.in);
	
	Queue<Integer> arrayDeque1 = new ArrayDeque<>();
	System.out.println("Enter number of elements:");
	int size = scan.nextInt();
	System.out.println("Enter the elements");
	for (int i = 0; i < size; i++) {
		int ele = scan.nextInt();
		arrayDeque1.add(ele);
	}
	
	System.out.println("Elements entered: "+arrayDeque1);
	List<Integer> l = oddEven(arrayDeque1);
	System.out.println("Result after rearranging : "+l);
}

public static List<Integer> oddEven(Queue<Integer> queue1) {
	Queue<Integer> evenList = new LinkedList<>();
	Queue<Integer> oddList = new LinkedList<>();
	while (!queue1.isEmpty()) {
		int l1 = queue1.poll();
		if (l1 % 2 == 0) {
			evenList.add(l1);
		} else {
			oddList.add(l1);
		}

	}
	
	List<Integer> arrayList = new ArrayList<>();
	while (!evenList.isEmpty() || !oddList.isEmpty()) {
		if (!evenList.isEmpty()) {
			arrayList.add(evenList.poll());
		}
		if (!oddList.isEmpty()) {
			arrayList.add(oddList.poll());
		}
	}
	return arrayList;
}

public static void  problem10() 
{
	Scanner sc1=new Scanner(System.in);
	Deque<Character> linkedList1=new LinkedList<>();
	System.out.println("Enter the number of Characters: ");
	int n=sc1.nextInt();
	System.out.println("Enter the Character : ");
	for(int j=0;j<n;j++)
	{
		linkedList1.addFirst(sc1.next().charAt(0));
	}
	System.out.println("Enter the number of Binary Numbers  :");
	int num=sc1.nextInt();
	int arrayl[]=new int[num];
	System.out.println("Enter the Binary Numbers: ");
	for(int i=0;i<num;i++) {
		arrayl[i]=sc1.nextInt();
	}
	sc1.close();
	removeCharacter(linkedList1,arrayl);
}

public static void removeCharacter(Deque<Character> d1,int[] array1) {
	
	char ch = 0;
	String s="";
	for(int i=0;i<array1.length;i++)
	{
		if(array1[i]==1)
		{
			ch=d1.removeLast();
		}
		if(array1[i]==0)
		{
			if(ch!=0)
			{
				d1.addLast(ch);
				ch=0;
			}
			
		}
	}
	int s1=d1.size();
	for(int i=0;i<s1;i++)
	{
		s+=d1.removeLast();
	}
	System.out.println("the output string is : "+ s);
}

}
